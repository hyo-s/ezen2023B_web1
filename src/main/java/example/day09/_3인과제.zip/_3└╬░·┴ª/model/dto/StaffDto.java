package example.day09._3인과제.model.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class StaffDto {
    private int sno;
    private String sname;
    private String sphone;
}
